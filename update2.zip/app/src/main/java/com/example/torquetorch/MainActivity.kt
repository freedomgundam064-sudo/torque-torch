package com.example.torquetorch

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme

class MainActivity : ComponentActivity() {
    private lateinit var torch: Torch
    private lateinit var billing: Billing

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        torch = Torch(applicationContext)
        val prefs = Prefs(applicationContext)
        // Debug builds (sideloaded for testing) are unlocked, since Play Billing only works on Play-installed builds.
        if (BuildConfig.DEBUG) prefs.setUnlocked(true)
        billing = Billing(applicationContext) { prefs.setUnlocked(it) }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                App(torch, prefs, billing, this)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!BuildConfig.DEBUG) billing.connect()
    }

    // The torch must never stay on (or keep a timer running) once the app leaves the screen.
    override fun onStop() {
        super.onStop()
        torch.off()
    }

    override fun onDestroy() {
        super.onDestroy()
        torch.release()
    }
}
