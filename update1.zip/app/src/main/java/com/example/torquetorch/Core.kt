package com.example.torquetorch

import android.app.Activity
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class Mode(val title: String, val glyph: String, val blurb: String) {
    STANDARD("STANDARD", "◉", "Steady light with adjustable brightness."),
    LOW("LOW", "◐", "Gentle, discreet light that's easy on the eyes."),
    TURBO("TURBO", "✦", "Maximum output the device allows."),
    STROBE("STROBE", "≋", "Adjustable flashing. Not for photosensitive users."),
    SOS("SOS", "▲", "Standard SOS pattern: three short, three long, three short.")
}

// ---------------------------------------------------------------- Torch

class Torch(context: Context) {
    private val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val id: String? = runCatching {
        cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    /** > 1 means the phone supports adjustable torch brightness (Android 13+). */
    val maxLevel: Int = if (Build.VERSION.SDK_INT >= 33 && id != null) {
        runCatching {
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
        }.getOrDefault(1)
    } else 1
    val supportsLevels: Boolean get() = maxLevel > 1

    var isOn by mutableStateOf(false); private set
    var mode by mutableStateOf(Mode.STANDARD); private set
    var level by mutableFloatStateOf(0.6f); private set
    var hz by mutableFloatStateOf(4f)
    var error by mutableStateOf<String?>(null)
    var strobeAck = false

    val effective: Float
        get() = when (mode) {
            Mode.LOW -> 0.1f
            Mode.TURBO -> 1f
            else -> level
        }

    private var available = true
    private var job: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    init {
        // Fires when another app takes the camera/flash.
        runCatching {
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeUnavailable(cameraId: String) {
                    if (cameraId != id) return
                    available = false
                    if (isOn) {
                        off()
                        error = "The flashlight is being used by another app."
                    }
                }

                override fun onTorchModeAvailable(cameraId: String) {
                    if (cameraId == id) available = true
                }
            }, Handler(Looper.getMainLooper()))
        }
    }

    fun toggle() = if (isOn) off() else on()

    fun on() {
        error = null
        if (id == null) { error = "This device doesn't have a flashlight."; return }
        if (!available) { error = "The flashlight is being used by another app."; return }
        isOn = true
        apply()
    }

    fun off() {
        job?.cancel(); job = null
        isOn = false
        set(false)
    }

    fun select(m: Mode) { mode = m; if (isOn) apply() }
    fun setLevel(v: Float) { level = v; if (isOn && mode == Mode.STANDARD) apply() }
    fun release() { scope.cancel(); off() }

    private fun apply() {
        job?.cancel(); job = null
        when (mode) {
            Mode.STANDARD, Mode.LOW, Mode.TURBO -> set(true, effective)
            Mode.STROBE -> job = scope.launch {
                while (isActive) {
                    val half = (500f / hz.coerceIn(1f, 10f)).toLong()
                    if (!set(true, effective)) return@launch
                    delay(half)
                    set(false)
                    delay(half)
                }
            }
            Mode.SOS -> job = scope.launch {
                val u = 200L
                val letters = listOf(listOf(1, 1, 1), listOf(3, 3, 3), listOf(1, 1, 1))
                while (isActive) {
                    for (letter in letters) {
                        for (d in letter) {
                            if (!set(true, effective)) return@launch
                            delay(d * u)
                            set(false)
                            delay(u)
                        }
                        delay(2 * u)
                    }
                    delay(4 * u)
                }
            }
        }
    }

    private fun set(on: Boolean, lvl: Float = 1f): Boolean {
        val i = id ?: return false
        return try {
            when {
                !on -> cm.setTorchMode(i, false)
                Build.VERSION.SDK_INT >= 33 && maxLevel > 1 ->
                    cm.turnOnTorchWithStrengthLevel(i, (lvl * maxLevel).toInt().coerceIn(1, maxLevel))
                else -> cm.setTorchMode(i, true)
            }
            true
        } catch (e: Exception) {
            if (on) {
                job?.cancel(); job = null
                isOn = false
                error = "Couldn't turn on the flashlight. Close other camera apps and try again."
            }
            false
        }
    }
}

// ---------------------------------------------------------------- Prefs

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var accent by mutableIntStateOf(sp.getInt("accent", 0)); private set
    var variant by mutableIntStateOf(sp.getInt("variant", 0)); private set
    var anim by mutableIntStateOf(sp.getInt("anim", 2)); private set          // 0 off, 1 subtle, 2 full
    var haptics by mutableStateOf(sp.getBoolean("haptics", true)); private set
    var sound by mutableStateOf(sp.getBoolean("sound", false)); private set
    var unlocked by mutableStateOf(sp.getBoolean("unlocked", false)); private set

    fun setAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun setVariant(v: Int) { variant = v; sp.edit().putInt("variant", v).apply() }
    fun setAnim(v: Int) { anim = v; sp.edit().putInt("anim", v).apply() }
    fun setHaptics(v: Boolean) { haptics = v; sp.edit().putBoolean("haptics", v).apply() }
    fun setSound(v: Boolean) { sound = v; sp.edit().putBoolean("sound", v).apply() }
    fun setUnlocked(v: Boolean) { unlocked = v; sp.edit().putBoolean("unlocked", v).apply() }
}

// ---------------------------------------------------------------- Billing

/** One non-consumable in-app product that unlocks the whole app. */
class Billing(context: Context, private val onOwned: (Boolean) -> Unit) : PurchasesUpdatedListener {
    companion object {
        /** Create an in-app product with this ID in Google Play Console. */
        const val PRODUCT_ID = "torque_torch_unlock"
    }

    var price by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null); private set
    var busy by mutableStateOf(false); private set

    private var details: ProductDetails? = null
    private val ok = BillingClient.BillingResponseCode.OK

    private val client: BillingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun connect() {
        if (client.isReady) { refresh(); return }
        if (client.connectionState == BillingClient.ConnectionState.CONNECTING) return
        message = null
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(r: BillingResult) {
                if (r.responseCode == ok) refresh()
                else message = "Google Play isn't available right now. Check your connection and try again."
            }

            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun refresh() {
        loadDetails()
        restore(false)
    }

    private fun loadDetails() {
        val p = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(PRODUCT_ID)
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        client.queryProductDetailsAsync(
            QueryProductDetailsParams.newBuilder().setProductList(listOf(p)).build()
        ) { _, list ->
            details = list.firstOrNull()
            price = details?.oneTimePurchaseOfferDetails?.formattedPrice
            if (details == null) message = "The purchase isn't available right now. Please try again later."
        }
    }

    fun buy(activity: Activity) {
        val d = details ?: run { connect(); return }
        busy = true
        message = null
        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build())
            ).build()
        val res = client.launchBillingFlow(activity, params)
        if (res.responseCode != ok) {
            busy = false
            message = "Couldn't open Google Play. Please try again."
        }
    }

    fun restore(userInitiated: Boolean) {
        if (!client.isReady) {
            if (userInitiated) message = "Connecting to Google Play…"
            connect()
            return
        }
        client.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        ) { r, list ->
            if (r.responseCode != ok) {
                if (userInitiated) message = "Couldn't reach Google Play. Please try again."
                return@queryPurchasesAsync
            }
            val owned = list.any {
                it.products.contains(PRODUCT_ID) && it.purchaseState == Purchase.PurchaseState.PURCHASED
            }
            handle(list)
            onOwned(owned)
            if (userInitiated) message = if (owned) null else "No previous purchase found for this Google account."
        }
    }

    private fun handle(purchases: List<Purchase>?) {
        purchases?.filter { it.products.contains(PRODUCT_ID) }?.forEach { p ->
            when (p.purchaseState) {
                Purchase.PurchaseState.PURCHASED -> {
                    if (!p.isAcknowledged) {
                        client.acknowledgePurchase(
                            AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()
                        ) { }
                    }
                    onOwned(true)
                }
                Purchase.PurchaseState.PENDING ->
                    message = "Purchase pending approval. The app unlocks once it's approved."
            }
        }
    }

    override fun onPurchasesUpdated(r: BillingResult, purchases: MutableList<Purchase>?) {
        busy = false
        val code = r.responseCode
        if (code == BillingClient.BillingResponseCode.OK) {
            handle(purchases)
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            // nothing to show
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            restore(false)
        } else if (code == BillingClient.BillingResponseCode.NETWORK_ERROR ||
            code == BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE
        ) {
            message = "You appear to be offline. Connect to the internet and try again."
        } else {
            message = "Something went wrong. Please try again."
        }
    }
}
