package com.example.torquetorch

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.view.SoundEffectConstants
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------------------------------------------------------------- Design system

object C {
    val charcoal = Color(0xFF121214)
    val graphite = Color(0xFF2A2C30)
    val metal = Color(0xFF8A8F98)
}

val accents = listOf(0xFFE5322D, 0xFFFFA619, 0xFF59BFFF, 0xFF9EE633, 0xFFEBEBEB).map { Color(it) }
val accentNames = listOf("Signal", "Amber", "Ice", "Lime", "Pearl")
val variantNames = listOf("Black", "Graphite", "Carbon")
val variantBrushes = listOf(
    listOf(Color.Black, Color.Black),
    listOf(Color(0xFF080809), Color(0xFF26282C)),
    listOf(Color.Black, Color(0xFF0D0F17))
)

class Fx(private val prefs: Prefs, private val h: HapticFeedback, private val v: View) {
    fun light() { if (prefs.haptics) h.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    fun heavy() {
        if (prefs.haptics) h.performHapticFeedback(HapticFeedbackType.LongPress)
        if (prefs.sound) v.playSoundEffect(SoundEffectConstants.CLICK)
    }
}

@Composable
fun rememberFx(prefs: Prefs): Fx = Fx(prefs, LocalHapticFeedback.current, LocalView.current)

@Composable
fun Eyebrow(text: String, color: Color = C.metal) {
    Text(text.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, color = color)
}

fun Modifier.panel(radius: Int = 22): Modifier =
    this.clip(RoundedCornerShape(radius.dp))
        .background(Color.White.copy(alpha = 0.06f))
        .border(0.5.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(radius.dp))

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var pct by remember { mutableIntStateOf(-1) }
    DisposableEffect(ctx) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { pct = pctOf(i) }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { pct = pctOf(it) }
        onDispose { runCatching { ctx.unregisterReceiver(r) } }
    }
    return pct
}

private fun pctOf(i: Intent): Int {
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (l < 0 || s <= 0) -1 else l * 100 / s
}

// ---------------------------------------------------------------- Root

enum class Page { HOME, MODES, CUSTOM }
enum class Overlay { SETTINGS, ABOUT, PRIVACY, EXPERIENCE }

@Composable
fun App(torch: Torch, prefs: Prefs, billing: Billing, activity: Activity) {
    val accent = accents[prefs.accent]
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(variantBrushes[prefs.variant]))
            .systemBarsPadding()
    ) {
        if (prefs.unlocked) Main(torch, prefs, billing, accent)
        else Paywall(billing, accent, activity)
    }
}

@Composable
fun Main(torch: Torch, prefs: Prefs, billing: Billing, accent: Color) {
    var page by remember { mutableStateOf(Page.HOME) }
    var overlay by remember { mutableStateOf<Overlay?>(null) }
    val fx = rememberFx(prefs)

    BackHandler(overlay != null) {
        overlay = if (overlay == Overlay.ABOUT || overlay == Overlay.PRIVACY) Overlay.SETTINGS else null
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar(accent) { fx.light(); overlay = Overlay.SETTINGS }
            Box(Modifier.weight(1f)) {
                when (page) {
                    Page.HOME -> Home(torch, prefs, accent, fx) { overlay = Overlay.EXPERIENCE }
                    Page.MODES -> Modes(torch, prefs, accent, fx)
                    Page.CUSTOM -> Customize(prefs, accent, fx)
                }
            }
            Dock(page, accent, fx) { page = it }
        }

        overlay?.let { ov ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(variantBrushes[prefs.variant]))
                    .pointerInput(Unit) {}
            ) {
                when (ov) {
                    Overlay.SETTINGS -> Settings(prefs, billing, accent,
                        onBack = { overlay = null },
                        onAbout = { overlay = Overlay.ABOUT },
                        onPrivacy = { overlay = Overlay.PRIVACY })
                    Overlay.ABOUT -> About(accent) { overlay = Overlay.SETTINGS }
                    Overlay.PRIVACY -> Privacy { overlay = Overlay.SETTINGS }
                    Overlay.EXPERIENCE -> Experience(torch, prefs, accent, fx) { overlay = null }
                }
            }
        }
    }

    torch.error?.let { msg ->
        AlertDialog(
            onDismissRequest = { torch.error = null },
            confirmButton = { TextButton(onClick = { torch.error = null }) { Text("OK") } },
            title = { Text("Flashlight unavailable") },
            text = { Text(msg) }
        )
    }
}

@Composable
fun TopBar(accent: Color, onSettings: () -> Unit) {
    val batt = rememberBattery()
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(14.dp, 3.dp).background(accent, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text("TORQUE TORCH", fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, color = Color.White)
        Spacer(Modifier.weight(1f))
        Text(if (batt >= 0) "$batt%" else "--", fontSize = 12.sp, color = C.metal, fontFeatureSettings = "tnum")
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White.copy(alpha = 0.85f))
        }
    }
}

@Composable
fun Dock(page: Page, accent: Color, fx: Fx, onSelect: (Page) -> Unit) {
    Row(
        Modifier
            .padding(horizontal = 24.dp, vertical = 8.dp)
            .fillMaxWidth()
            .panel(30)
            .padding(6.dp)
    ) {
        val items = listOf(
            Triple(Page.HOME, Icons.Default.Home, "Home"),
            Triple(Page.MODES, Icons.Default.Menu, "Modes"),
            Triple(Page.CUSTOM, Icons.Default.Edit, "Customize")
        )
        items.forEach { (p, icon, name) ->
            val sel = page == p
            val col = if (sel) accent else C.metal
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(if (sel) Color.White.copy(alpha = 0.08f) else Color.Transparent)
                    .clickable { fx.light(); onSelect(p) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, contentDescription = name, tint = col)
                Text(name.uppercase(), fontSize = 10.sp, letterSpacing = 2.sp, color = col, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ---------------------------------------------------------------- Screen 1: Home

@Composable
fun Home(torch: Torch, prefs: Prefs, accent: Color, fx: Fx, onExperience: () -> Unit) {
    val dim = remember { Animatable(0f) }
    val streak = remember { Animatable(-1.2f) }
    var first by remember { mutableStateOf(true) }

    LaunchedEffect(torch.isOn) {
        if (first) { first = false; return@LaunchedEffect }
        if (prefs.anim == 0) return@LaunchedEffect
        val on = torch.isOn
        val full = prefs.anim == 2
        streak.snapTo(if (on) -1.2f else 1.2f)
        launch {
            dim.animateTo(if (full) 0.55f else 0.3f, tween(100))
            delay(250)
            dim.animateTo(0f, tween(250))
        }
        streak.animateTo(if (on) 1.2f else -1.2f, tween(350))
    }

    val adjustable = torch.supportsLevels && (torch.mode == Mode.STANDARD || torch.mode == Mode.STROBE || torch.mode == Mode.SOS)
    val pct = if (!torch.supportsLevels) 100 else (torch.effective * 100).roundToInt()

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Eyebrow(torch.mode.title)
            Spacer(Modifier.height(16.dp))
            Box(Modifier.size(width = 320.dp, height = 240.dp), contentAlignment = Alignment.Center) {
                Beam(torch.isOn, accent, torch.effective, Modifier.align(Alignment.Center).offset190())
                Dial(torch.isOn, accent) { fx.heavy(); torch.toggle() }
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("$pct", fontSize = 72.sp, fontWeight = FontWeight.Light, color = Color.White, fontFeatureSettings = "tnum")
                Text("%", fontSize = 20.sp, fontWeight = FontWeight.Light, color = C.metal, modifier = Modifier.padding(bottom = 14.dp))
            }
            Eyebrow(
                when {
                    !torch.supportsLevels -> "Fixed on this device"
                    !adjustable -> "Fixed in ${torch.mode.title} mode"
                    else -> "Brightness"
                }
            )
            Slider(
                value = torch.level,
                onValueChange = { torch.setLevel(it) },
                valueRange = 0.05f..1f,
                enabled = adjustable,
                modifier = Modifier.padding(horizontal = 40.dp, vertical = 8.dp),
                colors = SliderDefaults.colors(
                    thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = C.graphite
                )
            )
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .panel(20)
                    .clickable { fx.light(); onExperience() }
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) { Eyebrow("Light Experience", Color.White) }
        }

        Canvas(Modifier.fillMaxSize()) {
            drawRect(Color.Black.copy(alpha = dim.value))
            val cx = size.width / 2 + streak.value * size.width * 0.6f
            val half = 90.dp.toPx()
            drawRect(
                Brush.horizontalGradient(
                    listOf(Color.Transparent, accent, Color.White, accent, Color.Transparent),
                    startX = cx - half, endX = cx + half
                ),
                topLeft = Offset(cx - half, size.height / 2 - 1.dp.toPx()),
                size = Size(half * 2, 2.dp.toPx())
            )
        }
    }
}

private fun Modifier.offset190(): Modifier = this.offset(y = (-190).dp)

@Composable
fun Beam(on: Boolean, color: Color, level: Float, modifier: Modifier) {
    val a by animateFloatAsState(if (on) 0.35f + 0.65f * level else 0f, tween(350), label = "beamAlpha")
    val s by animateFloatAsState(if (on) 1f else 0.1f, tween(350), label = "beamScale")
    Canvas(
        modifier
            .requiredSize(320.dp, 260.dp)
            .graphicsLayer { scaleY = s; transformOrigin = TransformOrigin(0.5f, 1f); alpha = a }
            .blur(8.dp)
    ) {
        val p = Path().apply {
            moveTo(size.width * 0.44f, size.height)
            lineTo(size.width * 0.56f, size.height)
            lineTo(size.width, 0f)
            lineTo(0f, 0f)
            close()
        }
        drawPath(p, Brush.verticalGradient(listOf(color.copy(alpha = 0f), color.copy(alpha = 0.5f))))
    }
}

@Composable
fun PowerGlyph(on: Boolean, modifier: Modifier = Modifier.size(56.dp)) {
    Canvas(modifier) {
        val c = if (on) Color.White else C.metal
        val w = 4.dp.toPx()
        val r = size.width * 0.36f
        val ctr = Offset(size.width / 2, size.height * 0.56f)
        drawArc(
            c, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(ctr.x - r, ctr.y - r), size = Size(r * 2, r * 2),
            style = Stroke(w, cap = StrokeCap.Round)
        )
        drawLine(c, Offset(ctr.x, size.height * 0.1f), Offset(ctr.x, ctr.y - r * 0.1f), w, StrokeCap.Round)
    }
}

@Composable
fun Dial(on: Boolean, accent: Color, onClick: () -> Unit) {
    val glow by animateFloatAsState(if (on) 1f else 0f, tween(400), label = "glow")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")
    Box(
        Modifier
            .size(220.dp)
            .scale(sc)
            .clickable(
                interactionSource = src, indication = null, role = Role.Button,
                onClickLabel = if (on) "Turn flashlight off" else "Turn flashlight on",
                onClick = onClick
            )
            .drawBehind {
                val r = size.minDimension / 2
                drawCircle(
                    Brush.radialGradient(listOf(accent.copy(alpha = 0.35f * glow), Color.Transparent), radius = r * 1.8f),
                    radius = r * 1.8f
                )
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color(0xFF383838), Color(0xFF0A0A0A)),
                        center = Offset(size.width * 0.3f, size.height * 0.3f), radius = r * 2f
                    ),
                    radius = r
                )
                drawCircle(
                    Brush.sweepGradient(
                        listOf(
                            Color.White.copy(alpha = 0.7f), C.metal.copy(alpha = 0.2f), Color.White.copy(alpha = 0.5f),
                            C.metal.copy(alpha = 0.15f), Color.White.copy(alpha = 0.7f)
                        )
                    ),
                    radius = r - 1.5.dp.toPx(), style = Stroke(3.dp.toPx())
                )
                drawCircle(accent.copy(alpha = 0.15f + 0.75f * glow), radius = r - 16.dp.toPx(), style = Stroke(1.5.dp.toPx()))
                for (i in 0 until 48) {
                    rotate(i * 7.5f) {
                        val len = if (i % 6 == 0) 10.dp.toPx() else 5.dp.toPx()
                        val y = center.y - r + 24.dp.toPx()
                        drawLine(
                            if (on) accent else C.metal.copy(alpha = 0.5f),
                            Offset(center.x, y), Offset(center.x, y + len), 2.dp.toPx()
                        )
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        PowerGlyph(on)
    }
}

// ---------------------------------------------------------------- Screen 2: Modes

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modes(torch: Torch, prefs: Prefs, accent: Color, fx: Fx) {
    var warn by remember { mutableStateOf(false) }
    val state = rememberLazyListState()

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Box(Modifier.padding(start = 24.dp, top = 16.dp)) { Eyebrow("Modes") }
        LazyRow(
            state = state,
            flingBehavior = rememberSnapFlingBehavior(state),
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(Mode.entries.toList()) { m ->
                val sel = torch.mode == m
                Column(
                    Modifier
                        .size(250.dp, 340.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                        .border(
                            if (sel) 1.dp else 0.5.dp,
                            if (sel) accent.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.16f),
                            RoundedCornerShape(28.dp)
                        )
                        .clickable {
                            fx.light()
                            if (m == Mode.STROBE && !torch.strobeAck) warn = true else torch.select(m)
                        }
                        .padding(22.dp)
                ) {
                    Text(m.glyph, fontSize = 40.sp, color = if (sel) accent else Color.White, fontWeight = FontWeight.Light)
                    Spacer(Modifier.weight(1f))
                    Text(m.title, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Text(m.blurb, fontSize = 14.sp, color = C.metal)
                    Spacer(Modifier.height(12.dp))
                    Box(
                        Modifier.fillMaxWidth().height(3.dp).clip(CircleShape)
                            .background(if (sel) accent else Color.White.copy(alpha = 0.1f))
                    )
                }
            }
        }

        if (torch.mode == Mode.STROBE) {
            Column(Modifier.padding(horizontal = 24.dp).fillMaxWidth().panel().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Eyebrow("Frequency")
                    Text("%.1f Hz".format(torch.hz), fontSize = 15.sp, color = Color.White, fontFeatureSettings = "tnum")
                }
                Slider(
                    value = torch.hz, onValueChange = { torch.hz = (it * 2).roundToInt() / 2f },
                    valueRange = 1f..10f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = C.graphite)
                )
                Text("Rapidly flashing lights may affect photosensitive users.", fontSize = 11.sp, color = C.metal)
            }
        }
    }

    if (warn) {
        AlertDialog(
            onDismissRequest = { warn = false },
            title = { Text("Photosensitivity warning") },
            text = {
                Text("Rapidly flashing lights can trigger seizures in people with photosensitive epilepsy. Don't use Strobe if you or anyone nearby may be affected.")
            },
            confirmButton = {
                TextButton(onClick = { torch.strobeAck = true; torch.select(Mode.STROBE); warn = false }) { Text("I understand") }
            },
            dismissButton = { TextButton(onClick = { warn = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- Screen 3: Customize

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().panel().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Eyebrow(title)
        content()
    }
}

@Composable
fun Seg(options: List<String>, selected: Int, accent: Color, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.08f)).padding(3.dp)
    ) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (i == selected) accent.copy(alpha = 0.25f) else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, fontSize = 14.sp, color = if (i == selected) Color.White else C.metal) }
        }
    }
}

@Composable
fun ToggleRow(label: String, value: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))
        Switch(
            checked = value, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun Customize(prefs: Prefs, accent: Color, fx: Fx) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Section("Accent colour") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                accents.forEachIndexed { i, c ->
                    Box(
                        Modifier.size(46.dp)
                            .then(if (prefs.accent == i) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                            .padding(5.dp).clip(CircleShape).background(c)
                            .clickable { fx.light(); prefs.setAccent(i) }
                    )
                }
            }
            Text(accentNames[prefs.accent], color = C.metal, fontSize = 12.sp)
        }
        Section("Animation intensity") {
            Seg(listOf("Off", "Subtle", "Full"), prefs.anim, accent) { prefs.setAnim(it) }
        }
        Section("Haptic feedback") {
            ToggleRow("Haptics", prefs.haptics, accent) { prefs.setHaptics(it) }
        }
        Section("Interface") {
            Seg(variantNames, prefs.variant, accent) { prefs.setVariant(it) }
        }
    }
}

// ---------------------------------------------------------------- Screen 4: Light Experience

@Composable
fun Experience(torch: Torch, prefs: Prefs, accent: Color, fx: Fx, onClose: () -> Unit) {
    val act = LocalContext.current as? Activity
    DisposableEffect(Unit) {
        act?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { act?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (torch.isOn) Rays(accent, torch.effective, prefs.anim)

        Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).panel(22).clickable { fx.light(); onClose() },
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 16.sp) }
            Spacer(Modifier.weight(1f))
            Eyebrow(torch.mode.title)
        }
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp).size(76.dp).panel(38)
                .then(if (torch.isOn) Modifier.border(1.5.dp, accent, CircleShape) else Modifier)
                .clickable { fx.heavy(); torch.toggle() },
            contentAlignment = Alignment.Center
        ) { PowerGlyph(torch.isOn, Modifier.size(34.dp)) }
    }
}

@Composable
private fun Rays(accent: Color, level: Float, anim: Int) {
    val inf = rememberInfiniteTransition(label = "rays")
    val t by inf.animateFloat(
        0f, 6.2832f, infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val mult = anim.toFloat()    // 0 off, 1 subtle, 2 full
    Canvas(Modifier.fillMaxSize().blur(14.dp)) {
        val origin = Offset(size.width / 2, size.height * 0.9f)
        val len = size.height * 1.1f
        for (i in 0 until 7) {
            val a = -Math.PI.toFloat() / 2 + (i - 3) * 0.16f + sin(t * mult + i) * 0.05f * mult
            val w = 0.07f
            val p = Path().apply {
                moveTo(origin.x, origin.y)
                lineTo(origin.x + cos(a - w) * len, origin.y + sin(a - w) * len)
                lineTo(origin.x + cos(a + w) * len, origin.y + sin(a + w) * len)
                close()
            }
            drawPath(p, Brush.verticalGradient(listOf(Color.Transparent, accent.copy(alpha = 0.5f * level)), startY = 0f, endY = origin.y))
        }
    }
}

// ---------------------------------------------------------------- Screen 5: Settings

@Composable
fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("‹", fontSize = 28.sp, color = Color.White) }
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

@Composable
fun Row2(label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 16.sp)
        Spacer(Modifier.weight(1f))
        Text("›", color = C.metal, fontSize = 20.sp)
    }
}

@Composable
fun Settings(prefs: Prefs, billing: Billing, accent: Color, onBack: () -> Unit, onAbout: () -> Unit, onPrivacy: () -> Unit) {
    val ctx = LocalContext.current
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Settings", onBack)
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Section("Feel") {
                ToggleRow("Haptic feedback", prefs.haptics, accent) { prefs.setHaptics(it) }
                ToggleRow("Animation", prefs.anim != 0, accent) { prefs.setAnim(if (it) 2 else 0) }
                ToggleRow("Sound effects", prefs.sound, accent) { prefs.setSound(it) }
            }
            Section("Legal & support") {
                Column {
                    Row2("Privacy", onPrivacy)
                    Row2("Terms") { runCatching { uri.openUri("https://example.com/terms") } }   // TODO: your terms URL
                    Row2("Support") {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:support@example.com"))) } // TODO
                    }
                }
            }
            Section("App") {
                Column {
                    Row2("Restore Purchases") { billing.restore(true) }
                    billing.message?.let { Text(it, color = C.metal, fontSize = 13.sp) }
                    Row2("About", onAbout)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Privacy(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Privacy", onBack)
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Privacy Policy", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            val body = listOf(
                "Torque Torch collects no personal data. There are no accounts, no analytics, no advertising and no tracking.",
                "The app uses your phone's flashlight and reads the battery level locally to display it. It does not use your camera, microphone, location or contacts, and it requests no permissions.",
                "Your settings (accent colour, haptics and similar) are stored only on your device.",
                "Purchases and Restore Purchases are handled entirely by Google Play. We never see your payment details."
            )
            body.forEach { Text(it, color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp) }
        }
    }
}

// ---------------------------------------------------------------- Screen 6: About

@Composable
fun About(accent: Color, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("About", onBack)
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(4.dp, 56.dp).background(accent))
            Spacer(Modifier.height(18.dp))
            Text("TORQUE TORCH", fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Eyebrow("Version 1.0")
            Spacer(Modifier.height(18.dp))
            Text(
                "An independent flashlight utility, designed with a love of precision engineering. It is not affiliated with, endorsed by, or sponsored by any automobile manufacturer.",
                color = C.metal, textAlign = TextAlign.Center, fontSize = 15.sp
            )
        }
    }
}

// ---------------------------------------------------------------- Purchase gate

@Composable
fun Paywall(billing: Billing, accent: Color, activity: Activity) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(4.dp, 56.dp).background(accent))
        Spacer(Modifier.height(16.dp))
        Text("TORQUE TORCH", fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp, color = Color.White)
        Spacer(Modifier.height(12.dp))
        Text(
            "One purchase. Everything unlocked.\nNo subscription, no ads, no account.",
            color = C.metal, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth().panel().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(
                "Five modes: Standard, Low, Turbo, Strobe, SOS",
                "Precision brightness control",
                "Light Experience full-screen mode",
                "Customisable accent, haptics and interface"
            ).forEach {
                Row { Text("✓", color = accent, fontWeight = FontWeight.Bold); Spacer(Modifier.width(10.dp)); Text(it, fontSize = 14.sp, color = Color.White) }
            }
        }
        Spacer(Modifier.weight(1f))
        billing.message?.let {
            Text(it, fontSize = 13.sp, color = C.metal, textAlign = TextAlign.Center)
            if (billing.price == null) TextButton(onClick = { billing.connect() }) { Text("Try again") }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(27.dp)).background(accent)
                .clickable(enabled = billing.price != null && !billing.busy) { billing.buy(activity) },
            contentAlignment = Alignment.Center
        ) {
            if (billing.busy) CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            else Text(
                billing.price?.let { "Unlock for $it" } ?: "Unlock",
                color = Color.Black, fontWeight = FontWeight.SemiBold, fontSize = 17.sp
            )
        }
        TextButton(onClick = { billing.restore(true) }, enabled = !billing.busy) {
            Text("Restore Purchases", color = Color.White)
        }
        Text("Independent app. Not affiliated with any automobile manufacturer.", fontSize = 10.sp, color = C.metal)
    }
}
